!function ($) {
  $(function(){

    // make code pretty
    window.prettyPrint && prettyPrint()
})
}(window.jQuery)